package pl.edu.wszib.lab1;

public interface MySecondInterface {
    void run2();
}
