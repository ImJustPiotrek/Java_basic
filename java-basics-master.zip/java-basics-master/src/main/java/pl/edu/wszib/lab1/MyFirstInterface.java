package pl.edu.wszib.lab1;

public interface MyFirstInterface {
    void run1();
}
